java -cp hsqldb.jar org.hsqldb.util.DatabaseManager
